# Codex Skills Migration Archive

This archive contains your user-level Codex Skills and optional configuration.

## How to import on a new Mac

### Option A: Using the standalone installer (no skill-manager required)

```bash
# 1. Extract the archive
tar -xzf codex-skills-migration-YYYYMMDD-HHMMSS.tar.gz
cd codex-skill-migration

# 2. Preview what will be imported
python3 install_import.py --dry-run

# 3. Import
python3 install_import.py --yes
```

### Option B: Using skill-manager (if already installed)

```bash
python3 ~/.agents/skills/skill-manager/scripts/skillctl.py verify-archive <archive.tar.gz>
python3 ~/.agents/skills/skill-manager/scripts/skillctl.py import <archive.tar.gz>
python3 ~/.agents/skills/skill-manager/scripts/skillctl.py import <archive.tar.gz> --yes
```

## Safety

- Dry-run is the default. Nothing is written without `--yes`.
- Existing skills are backed up before being overwritten.
- AGENTS.md content is appended, not replaced.
- Login credentials, API keys, and secrets are excluded from the archive.
