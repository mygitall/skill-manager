#!/usr/bin/env python3
"""Standalone Codex Skills Migration importer.

Usage:
  python3 install_import.py --dry-run     # preview only
  python3 install_import.py --yes          # import
  python3 install_import.py --yes --mode merge       # default
  python3 install_import.py --yes --mode overwrite
  python3 install_import.py --yes --mode skip-existing
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

HOME = Path.home()
SKILLS = HOME / ".agents" / "skills"
BACKUPS = SKILLS / ".backups"
CODEX = HOME / ".codex"
MANIFEST_FILE = Path(__file__).parent / "manifest.json"
USER_SKILLS_DIR = Path(__file__).parent / "user-skills"
OPTIONAL_DIR = Path(__file__).parent / "optional"


def now_stamp():
    return datetime.now().strftime("%Y%m%d-%H%M%S")


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def backup_path(src: Path) -> Path:
    stamp = now_stamp()
    dest = BACKUPS / f"import-{stamp}" / src.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    if src.is_dir():
        shutil.copytree(src, dest)
    else:
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dest)
    return dest


def load_manifest():
    if not MANIFEST_FILE.exists():
        print("ERROR: manifest.json not found", file=sys.stderr)
        sys.exit(1)
    with open(MANIFEST_FILE) as f:
        return json.load(f)


def import_skills(manifest, mode, dry_run):
    skills_dir = USER_SKILLS_DIR
    if not skills_dir.exists():
        print("No user-skills directory in archive")
        return

    existing_skills = set()
    if SKILLS.exists():
        for d in SKILLS.iterdir():
            if d.is_dir() and (d / "SKILL.md").exists():
                existing_skills.add(d.name)

    for child in sorted(skills_dir.iterdir()):
        if not child.is_dir():
            continue
        md = child / "SKILL.md"
        if not md.exists():
            continue
        name = child.name
        dest = SKILLS / name

        if dest.exists():
            if mode == "skip-existing":
                print(f"  SKIP (exists): {name}")
                continue
            elif mode == "merge" or mode == "overwrite":
                bkp = backup_path(dest)
                if dry_run:
                    print(f"  BACKUP (dry-run): {bkp}")
                else:
                    print(f"  BACKUP: {bkp}")
                if not dry_run:
                    if dest.is_dir():
                        shutil.rmtree(dest)
                    else:
                        dest.unlink()

        if dry_run:
            print(f"  IMPORT (dry-run): {name}")
        else:
            SKILLS.mkdir(parents=True, exist_ok=True)
            shutil.copytree(child, dest)
            print(f"  IMPORT: {name}")


def import_agents_md(manifest, mode, dry_run):
    agents_src = OPTIONAL_DIR / "codex" / "AGENTS.md"
    if not agents_src.exists():
        return

    dest = CODEX / "AGENTS.md"
    stamp = now_stamp()
    marker_start = f"<!-- imported-codex-agents-start: {stamp} -->"
    marker_end = "<!-- imported-codex-agents-end -->"

    # Check for previous import from same manifest
    if dest.exists():
        existing = dest.read_text(encoding="utf-8")
        manifest_hash = sha256_file(agents_src)
        if manifest_hash in existing:
            print(f"  SKIP AGENTS.md (already imported from this archive)")
            return

    if dry_run:
        if dest.exists():
            print(f"  APPEND AGENTS.md (dry-run, will add {marker_start})")
        else:
            print(f"  CREATE AGENTS.md (dry-run)")
        return

    content = agents_src.read_text(encoding="utf-8")
    block = f"\n{marker_start}\n{content}\n{marker_end}\n"

    if dest.exists():
        bkp = backup_path(dest)
        print(f"  BACKUP AGENTS.md: {bkp}")
        existing = dest.read_text(encoding="utf-8")
        dest.write_text(existing + block, encoding="utf-8")
        print(f"  APPEND AGENTS.md")
    else:
        CODEX.mkdir(parents=True, exist_ok=True)
        dest.write_text(content + "\n", encoding="utf-8")
        print(f"  CREATE AGENTS.md")


def import_hooks(manifest, mode, dry_run):
    hooks_src = OPTIONAL_DIR / "codex" / "hooks"
    if not hooks_src.exists():
        return

    dest_dir = CODEX / "hooks"
    dest_dir.mkdir(parents=True, exist_ok=True)

    for fpath in sorted(hooks_src.rglob("*")):
        if fpath.is_dir():
            continue
        rel = fpath.relative_to(hooks_src)
        dest = dest_dir / rel

        if dest.exists():
            if mode == "skip-existing":
                print(f"  SKIP hook: {rel}")
                continue
            bkp = backup_path(dest)
            if dry_run:
                print(f"  BACKUP hook (dry-run): {bkp}")
            else:
                print(f"  BACKUP hook: {bkp}")

        if dry_run:
            print(f"  IMPORT hook (dry-run): {rel}")
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(fpath, dest)
            if fpath.suffix == ".py":
                os.chmod(dest, fpath.stat().st_mode | 0o111)
            print(f"  IMPORT hook: {rel}")

    if not dry_run:
        print("  NOTE: Check hook configuration manually. Hooks are not auto-enabled.")


def import_prompts(manifest, mode, dry_run):
    prompts_src = OPTIONAL_DIR / "codex" / "prompts"
    if not prompts_src.exists():
        return

    dest_dir = CODEX / "prompts"
    dest_dir.mkdir(parents=True, exist_ok=True)

    for fpath in sorted(prompts_src.rglob("*")):
        if fpath.is_dir():
            continue
        rel = fpath.relative_to(prompts_src)
        dest = dest_dir / rel

        if dest.exists():
            if mode == "skip-existing":
                print(f"  SKIP prompt: {rel}")
                continue
            bkp = backup_path(dest)
            if dry_run:
                print(f"  BACKUP prompt (dry-run): {bkp}")
            else:
                print(f"  BACKUP prompt: {bkp}")

        if dry_run:
            print(f"  IMPORT prompt (dry-run): {rel}")
        else:
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(fpath, dest)
            print(f"  IMPORT prompt: {rel}")


def main():
    parser = argparse.ArgumentParser(description="Codex Skills Migration Importer")
    parser.add_argument("--dry-run", action="store_true", help="Preview only, no writes")
    parser.add_argument("--yes", action="store_true", help="Confirm import")
    parser.add_argument("--mode", choices=["merge", "overwrite", "skip-existing"],
                        default="merge", help="Import mode (default: merge)")
    args = parser.parse_args()

    if not args.dry_run and not args.yes:
        print("ERROR: Use --dry-run to preview or --yes to confirm import", file=sys.stderr)
        sys.exit(1)

    manifest = load_manifest()
    print(f"Archive: {manifest.get('format')} created {manifest.get('created_at')}")
    print(f"Includes: {json.dumps(manifest.get('includes', {}))}")
    print(f"Skills: {len([f for f in manifest.get('files', []) if f['path'].startswith('user-skills/')])}")
    print()

    mode = args.mode
    dry_run = args.dry_run

    print(f"Mode: {mode} | Dry-run: {dry_run}")
    print()

    print("=== Skills ===")
    import_skills(manifest, mode, dry_run)
    print()

    print("=== AGENTS.md ===")
    import_agents_md(manifest, mode, dry_run)
    print()

    print("=== Hooks ===")
    import_hooks(manifest, mode, dry_run)
    print()

    print("=== Prompts ===")
    import_prompts(manifest, mode, dry_run)
    print()

    if dry_run:
        print("Dry-run complete. Re-run with --yes to import.")
    else:
        print("Import complete.")


if __name__ == "__main__":
    main()
