---
name: token-saver
description: Use when coding, debugging, refactoring, reviewing, or working in long Codex sessions where token saving matters but code correctness must not be sacrificed. Enforces search-before-read, scoped file reading, concise output, verification-first coding, context compaction reminders, and handoff summaries, and handoff summaries.
---

# Token Saver Skill

This skill makes Codex work with fewer tokens while preserving code quality.

The goal is not to read as little as possible.
The goal is to avoid waste while still collecting enough evidence to write correct code.

Correctness is higher priority than token saving.

---

## Core priorities

Follow this priority order:

1. Correctness
2. Build/test/lint verification
3. Minimal safe changes
4. Token efficiency
5. Concise explanation

Never save tokens by guessing.
Never save tokens by skipping necessary verification.
Never save tokens by ignoring error logs, imports, call sites, routes, configs, or tests.

---

## Default behavior

When this skill is active:

- Be concise.
- Search before reading files.
- Read only files that are relevant to the task.
- Prefer small diffs over broad rewrites.
- Prefer verification commands over long explanations.
- Avoid repeated explanation of known context.
- Avoid unnecessary architecture changes.
- Avoid speculative improvements.
- Avoid touching files unrelated to the user's request.
- Do not generate large tutorials unless the user explicitly asks.

---

## Search-before-read rule

Before opening files, prefer scoped discovery commands such as:

- `git status`
- `git diff --stat`
- `git diff -- <file>`
- `rg "<keyword>"`
- `rg --files`
- `find . -maxdepth 3 -type f`
- `tree -L 2`
- package/build/test config inspection
- compiler/test/runtime error locations

Do not start by recursively reading the whole project.

Do not use `cat` on large files as the first step.

---

## Default file-reading budget

The default first-pass reading budget is:

- max 3 files;
- max 200 lines per file;
- prefer targeted line ranges;
- prefer reading function/class/import/config sections instead of whole files.

This is a soft budget, not a hard limit.

Codex may exceed this budget when correctness requires it.

---

## When Codex may read more files

Codex may read more than the default budget only when at least one condition is true:

1. The current error cannot be diagnosed from the files already inspected.
2. The issue involves cross-file references.
3. The issue involves imports, exports, routes, dependency injection, build config, generated types, resource linking, or app manifests.
4. A compiler, test, lint, or runtime error points to another file.
5. The user requested a feature that touches multiple modules.
6. The task involves API contracts, database schema, UI state, navigation, or shared components.
7. Codex is uncertain and can cheaply verify the answer by inspecting another exact file.

Before reading more files, Codex must briefly state:

- what is already known;
- what is still uncertain;
- which exact files or search commands are needed;
- why reading them improves correctness.

Do not ask the user for permission if the next file is clearly necessary and low-risk.
Just state the reason briefly and continue.

---

## Large file handling

If a file is larger than 500 lines:

1. Do not read the whole file first.
2. First inspect structure:
   - imports;
   - class names;
   - function names;
   - route names;
   - exported symbols;
   - config blocks;
   - error line ranges;
   - relevant search hits.
3. Then read only the relevant region.

If the whole file truly must be read, explain why in one sentence.

---

## Ignore directories by default

Do not read these directories unless the user explicitly asks or the error directly points there:

- `.git/`
- `node_modules/`
- `dist/`
- `build/`
- `.gradle/`
- `.idea/`
- `.vscode/`
- `Pods/`
- `DerivedData/`
- `.next/`
- `.nuxt/`
- `vendor/`
- `coverage/`
- `logs/`
- `tmp/`
- binary files
- images
- videos
- archives
- huge lock files
- generated files

Lock files may be inspected only when dependency resolution requires it.

---

## Code quality protection

Token saving must never reduce code quality.

For code tasks:

- understand the failing path before editing;
- avoid blind patches;
- check imports and call sites when relevant;
- preserve existing style;
- prefer minimal diffs;
- avoid unrelated formatting;
- avoid broad refactors unless explicitly requested;
- do not remove code unless you understand its purpose;
- do not introduce new dependencies unless necessary;
- do not create duplicate helpers if existing helpers can be reused;
- do not add fallback implementations just to make the code "feel safer";
- do not silence errors without fixing root cause.

If there are multiple possible fixes, choose the smallest fix that addresses the verified cause.

---

## Verification-first rule

After modifying code, run the smallest relevant verification command when possible.

Examples:

- JavaScript/TypeScript:
  - `npm run build`
  - `npm test`
  - `npm run lint`
  - `npx tsc --noEmit`

- Android:
  - `./gradlew assembleDebug`
  - `./gradlew test`
  - `./gradlew lint`

- iOS:
  - `xcodebuild`
  - relevant scheme build command if available

- Python:
  - `python -m pytest`
  - `python -m compileall`
  - `ruff check`

- PHP:
  - `php -l <file>`
  - project test command if available

If verification cannot be run, explain why briefly.

Do not skip verification just to save tokens.

Show only:

- command run;
- pass/fail result;
- important error summary;
- next fix if needed.

Do not paste full logs unless necessary.

---

## Long-task behavior

For tasks with multiple steps:

1. Give a short plan with 3 to 6 steps.
2. Complete one phase at a time.
3. Summarize after each phase.
4. Do not expand scope without a reason.
5. Prefer stopping at a stable checkpoint over continuing endlessly.
6. If the task becomes large, suggest `/compact`.

A task is considered long when:

- more than 8 files are touched;
- more than 8 back-and-forth turns happen;
- the same issue needs repeated debugging;
- the conversation contains many logs;
- Codex starts losing track of previous decisions;
- context becomes noisy;
- the user asks to continue from earlier work.

---

## Context compaction rule

Suggest `/compact` when:

- the conversation is long;
- the task has reached a stable checkpoint;
- many files were inspected;
- many logs were discussed;
- the next step can be continued from a summary;
- Codex may start wasting tokens by re-reading old context.

Do not suggest `/compact` in the middle of a fragile debugging step unless a checkpoint summary is available.

---

## New session rule

Suggest opening a new session when:

- the current task is complete;
- the next task is unrelated;
- the context contains too many old decisions;
- the user is switching projects;
- the user is switching from debugging to a new feature;
- the previous conversation may bias the next task.

Always provide a handoff summary before suggesting a new session.

---

## Handoff summary

At the end of every completed task, provide a short handoff summary.

Keep it under 10 lines.

It must include:

- Goal
- Files changed
- Current status
- Verification command/result
- Remaining TODO
- Suggested next action

This summary should be useful if the user opens a new Codex session.

---

## Default final response format

Unless the user asks for a detailed explanation, final responses should use this format:

```text
Done:
- ...

Changed files:
- ...

Verification:
- ...

Risks / notes:
- ...

Token/context:
- /compact recommended: yes/no, reason
- New session recommended: yes/no, reason

Handoff summary:
- Goal:
- Changed:
- Status:
- Verified:
- TODO:
- Next:

Keep it concise.

Do not paste full file contents.
Do not paste full logs.
Do not explain obvious things.
Do not repeat the user's request back to them.

Strict anti-waste rules

Do not do these unless explicitly required:

read the entire repository;
read unrelated directories;
paste full source files into chat;
explain basic programming concepts;
rewrite working modules;
add new architecture;
add new dependencies;
generate duplicate utilities;
run expensive commands repeatedly;
keep debugging without summarizing;
continue after a stable checkpoint without asking or summarizing.
Safe expansion rule

If the first-pass budget is insufficient, do not stop.

Instead say briefly:

Need more context for correctness:
- Known:
- Uncertain:
- Next files/search:
- Reason:

Then continue with the smallest necessary inspection.

This skill saves tokens by avoiding waste, not by reducing correctness.
